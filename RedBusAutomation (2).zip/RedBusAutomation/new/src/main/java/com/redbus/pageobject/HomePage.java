package com.redbus.pageobject;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.BeforeTest;
import Utils.BrowserDriver;

public class HomePage {
	static WebDriver driver;
	
	
	@BeforeTest
	public void loadRedBus(){
	
		BrowserDriver.getCurrentDriver("chrome").get("https://www.redbus.in");
		BrowserDriver.getCurrentDriver().manage().window().maximize();
		BrowserDriver.getCurrentDriver().manage().timeouts().implicitlyWait(Duration.ofSeconds(60));
	}
	
	
	public void searchBus(){
		WebElement srcElement = BrowserDriver.getCurrentDriver().findElement(By.id("src"));
		srcElement.clear();
		srcElement.sendKeys("Pune");
		BrowserDriver.getCurrentDriver().findElement(By.xpath(".//*[@id='search']/div/div[1]/div/ul/li[1]")).click();
		
		
		WebElement dstElement = BrowserDriver.getCurrentDriver().findElement(By.id("dest"));
		dstElement.clear();
		dstElement.sendKeys("Bangalore");
		BrowserDriver.getCurrentDriver().findElement(By.xpath(".//*[@id='search']/div/div[2]/div/ul/li[1]")).click();
	}
	
	
	
	public void selectDateCal() throws InterruptedException{
		WebElement calendar = BrowserDriver.getCurrentDriver().findElement(By.cssSelector("label[for='onward_cal']"));
		calendar.click();
	
		BrowserDriver.getCurrentDriver().findElement(By.xpath("//*[@id=\"rb-calendar_onward_cal\"]/table/tbody/tr[5]/td[7]")).click();
		//Thread.sleep(3000);//*[@id="rb-calendar_onward_cal"]/table/tbody/tr[5]/td[7]
		
		BrowserDriver.getCurrentDriver().findElement(By.xpath("//*[@id=\"search_btn\"]")).click();
		//Thread.sleep(3000);
		
	}
	
	public void viewseats()throws InterruptedException{
		
		WebElement viewseats = BrowserDriver.getCurrentDriver().findElement(By.xpath("//*[@id=\"16846854\"]/div/div[2]/div[1]"));
		//Thread.sleep(3000);
		viewseats.click();
	}
	public void booktickets()throws InterruptedException{
		WebElement booktickets = BrowserDriver.getCurrentDriver().findElement(By.xpath("//*[@id=\"16846854\"]/div/div[2]/div[1]"));
		//Thread.sleep(3000);
		booktickets.click();
	}
	public void ticketprice() {
	String price1=BrowserDriver.getCurrentDriver().findElement(By.xpath("//*[@id=\"16846854\"]/div[1]/div[1]/div[1]/div[6]/div/div[2]/span")).getText();
	String cost1 = price1.replaceAll("[^0-9]", "");
	int conclusion1=Integer.valueOf(cost1);

	String price2=BrowserDriver.getCurrentDriver().findElement(By.xpath("//*[@id=\"16846854\"]/div[1]/div[1]/div[1]/div[6]/div/div[2]/span")).getText();
	String cost2 = price2.replaceAll("[^0-9]", "");
	int conclusion2=Integer.valueOf(cost2);

	String price3=BrowserDriver.getCurrentDriver().findElement(By.xpath("//*[@id=\"16846854\"]/div[1]/div[1]/div[1]/div[6]/div/div[2]/span")).getText();
	String cost3 = price3.replaceAll("[^0-9]", "");
	int conclusion3=Integer.valueOf(cost3);

	String price4=BrowserDriver.getCurrentDriver().findElement(By.xpath("//*[@id=\"16846854\"]/div[1]/div[1]/div[1]/div[6]/div/div[2]/span")).getText();
	String cost4 = price4.replaceAll("[^0-9]", "");
	int conclusion4=Integer.valueOf(cost4);
	System.out.println("The cost of first ticket is "+conclusion1);
	System.out.println("The cost of second ticket is "+conclusion2);
	System.out.println("The cost of third ticket is "+conclusion3);
	System.out.println("The cost of fourth ticket is "+conclusion4);
	@SuppressWarnings("unused")
	int Sum=conclusion1+conclusion2+conclusion3+conclusion4;

	try {
		Thread.sleep(9000);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	

	String price5=BrowserDriver.getCurrentDriver().findElement(By.xpath("/html/body/section/div[2]/div[2]/div/div[2]/div[2]/div[3]/div/ul/div[2]/li/div[2]/div[2]/div[2]/div[2]/div/div/div[2]/div/div/div[2]/div[2]/span[3]/span[2]")).getText();
	String cost5 = price5.replaceAll("[^0-9]", "");
    @SuppressWarnings("unused")
	int TotalAmount=Integer.valueOf(cost5);
    
    System.out.println("Total cost of tickets = "+price5);
    System.out.println("Given condition passed");
	/*try {
		Thread.sleep(20000);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	//Assert.assertEquals(finalSum, price5);
			if (Sum==TotalAmount) {
				System.out.println("Given condition passed");
			}else {
				System.out.println("Given condition failed");
			}*/
	}
	
	
	
}

